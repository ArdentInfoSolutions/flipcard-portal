export const publicRoutes = ['/', '/login', '/about']; // Public routes
export const protectedRoutes = ['/profile', '/dashboard', '/post/[id]']; // Protected routes
