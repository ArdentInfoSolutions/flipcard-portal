(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_upload_socialmediapost_page_tsx_7095e4._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_upload_socialmediapost_page_tsx_7095e4._.js",
  "chunks": [
    "static/chunks/node_modules_6e815e._.js",
    "static/chunks/src_cd68c3._.js"
  ],
  "source": "dynamic"
});
